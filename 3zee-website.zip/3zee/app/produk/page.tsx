"use client";
import { useState, useMemo } from "react";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import ProductCard from "../components/ProductCard";
import { products, categories } from "../lib/data";
import { Search, SlidersHorizontal, X, ChevronLeft, ChevronRight } from "lucide-react";

const ITEMS_PER_PAGE = 12;

export default function ProdukPage() {
  const [search, setSearch] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("Semua");
  const [sortBy, setSortBy] = useState("default");
  const [page, setPage] = useState(1);
  const [showFilter, setShowFilter] = useState(false);

  const allCategories = ["Semua", ...categories.map((c) => c.name)];

  const filtered = useMemo(() => {
    let result = [...products];
    if (selectedCategory !== "Semua") {
      result = result.filter((p) => p.category === selectedCategory);
    }
    if (search) {
      result = result.filter((p) =>
        p.name.toLowerCase().includes(search.toLowerCase())
      );
    }
    if (sortBy === "price-asc") result.sort((a, b) => a.price - b.price);
    if (sortBy === "price-desc") result.sort((a, b) => b.price - a.price);
    if (sortBy === "rating") result.sort((a, b) => b.rating - a.rating);
    if (sortBy === "popular") result.sort((a, b) => b.sold - a.sold);
    return result;
  }, [search, selectedCategory, sortBy]);

  const totalPages = Math.ceil(filtered.length / ITEMS_PER_PAGE);
  const paginated = filtered.slice((page - 1) * ITEMS_PER_PAGE, page * ITEMS_PER_PAGE);

  return (
    <>
      <Navbar />

      {/* Page hero */}
      <div className="bg-[#0d1f3c] pt-28 pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="flex items-center justify-center gap-3 mb-3">
            <div className="h-px w-10 bg-[#c9a227]" />
            <span className="text-[#c9a227] text-xs tracking-[0.4em] uppercase font-body">Koleksi</span>
            <div className="h-px w-10 bg-[#c9a227]" />
          </div>
          <h1 className="font-serif text-4xl md:text-5xl font-bold text-white mb-3">Semua Produk</h1>
          <p className="font-body text-white/60 text-sm">
            {filtered.length} produk ditemukan
          </p>
        </div>
      </div>

      <div className="bg-[#faf8f4] min-h-screen">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
          {/* Search & filter bar */}
          <div className="bg-white border border-[#c9a227]/20 rounded-sm p-4 mb-8 flex flex-col md:flex-row gap-4 items-stretch md:items-center">
            {/* Search */}
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4" />
              <input
                type="text"
                placeholder="Cari produk..."
                value={search}
                onChange={(e) => { setSearch(e.target.value); setPage(1); }}
                className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-sm font-body text-sm focus:outline-none focus:border-[#c9a227] transition-colors"
              />
              {search && (
                <button onClick={() => setSearch("")} className="absolute right-3 top-1/2 -translate-y-1/2">
                  <X className="w-4 h-4 text-gray-400 hover:text-gray-600" />
                </button>
              )}
            </div>

            {/* Sort */}
            <select
              value={sortBy}
              onChange={(e) => { setSortBy(e.target.value); setPage(1); }}
              className="border border-gray-200 rounded-sm px-4 py-2.5 font-body text-sm focus:outline-none focus:border-[#c9a227] bg-white transition-colors"
            >
              <option value="default">Urutan Default</option>
              <option value="price-asc">Harga: Terendah</option>
              <option value="price-desc">Harga: Tertinggi</option>
              <option value="rating">Rating Terbaik</option>
              <option value="popular">Terpopuler</option>
            </select>

            {/* Filter toggle (mobile) */}
            <button
              onClick={() => setShowFilter(!showFilter)}
              className="flex items-center gap-2 border border-[#c9a227] text-[#c9a227] px-4 py-2.5 rounded-sm font-body text-sm md:hidden"
            >
              <SlidersHorizontal size={14} />
              Filter
            </button>
          </div>

          <div className="flex gap-8">
            {/* Sidebar filter (desktop) */}
            <aside className={`hidden md:block w-56 flex-shrink-0`}>
              <div className="bg-white border border-[#c9a227]/20 rounded-sm p-5 sticky top-24">
                <h3 className="font-serif text-[#0d1f3c] font-semibold text-lg mb-4">Kategori</h3>
                <ul className="space-y-1">
                  {allCategories.map((cat) => (
                    <li key={cat}>
                      <button
                        onClick={() => { setSelectedCategory(cat); setPage(1); }}
                        className={`w-full text-left px-3 py-2 rounded-sm font-body text-sm transition-all duration-200 ${
                          selectedCategory === cat
                            ? "bg-[#0d1f3c] text-[#c9a227] font-semibold"
                            : "text-gray-600 hover:bg-[#c9a227]/10 hover:text-[#0d1f3c]"
                        }`}
                      >
                        {cat}
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            </aside>

            {/* Mobile filter */}
            {showFilter && (
              <div className="md:hidden fixed inset-0 z-50 bg-black/50 flex items-end">
                <div className="bg-white w-full rounded-t-2xl p-6">
                  <div className="flex items-center justify-between mb-5">
                    <h3 className="font-serif text-[#0d1f3c] font-semibold text-xl">Kategori</h3>
                    <button onClick={() => setShowFilter(false)}>
                      <X className="w-5 h-5 text-gray-500" />
                    </button>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    {allCategories.map((cat) => (
                      <button
                        key={cat}
                        onClick={() => { setSelectedCategory(cat); setShowFilter(false); setPage(1); }}
                        className={`px-4 py-3 rounded-sm font-body text-sm border transition-all ${
                          selectedCategory === cat
                            ? "bg-[#0d1f3c] border-[#0d1f3c] text-[#c9a227] font-semibold"
                            : "border-gray-200 text-gray-600"
                        }`}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Products grid */}
            <div className="flex-1">
              {/* Mobile filter chips */}
              <div className="flex gap-2 mb-5 flex-wrap md:hidden">
                {allCategories.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => { setSelectedCategory(cat); setPage(1); }}
                    className={`px-3 py-1.5 rounded-full font-body text-xs border transition-all ${
                      selectedCategory === cat
                        ? "bg-[#0d1f3c] border-[#0d1f3c] text-[#c9a227]"
                        : "border-gray-300 text-gray-600"
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>

              {paginated.length === 0 ? (
                <div className="text-center py-20">
                  <p className="font-serif text-[#0d1f3c] text-2xl font-semibold mb-2">Produk tidak ditemukan</p>
                  <p className="font-body text-gray-500 text-sm">Coba ubah filter atau kata kunci pencarian.</p>
                </div>
              ) : (
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {paginated.map((product) => (
                    <ProductCard key={product.id} product={product} />
                  ))}
                </div>
              )}

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="flex items-center justify-center gap-2 mt-10">
                  <button
                    onClick={() => setPage((p) => Math.max(1, p - 1))}
                    disabled={page === 1}
                    className="w-9 h-9 border border-[#0d1f3c] flex items-center justify-center disabled:opacity-40 hover:bg-[#0d1f3c] hover:text-white transition-all rounded-sm"
                  >
                    <ChevronLeft size={16} />
                  </button>

                  {[...Array(totalPages)].map((_, i) => (
                    <button
                      key={i}
                      onClick={() => setPage(i + 1)}
                      className={`w-9 h-9 border font-body text-sm font-semibold transition-all rounded-sm ${
                        page === i + 1
                          ? "bg-[#0d1f3c] border-[#0d1f3c] text-[#c9a227]"
                          : "border-[#0d1f3c]/30 text-[#0d1f3c] hover:border-[#0d1f3c] hover:bg-[#0d1f3c] hover:text-white"
                      }`}
                    >
                      {i + 1}
                    </button>
                  ))}

                  <button
                    onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                    disabled={page === totalPages}
                    className="w-9 h-9 border border-[#0d1f3c] flex items-center justify-center disabled:opacity-40 hover:bg-[#0d1f3c] hover:text-white transition-all rounded-sm"
                  >
                    <ChevronRight size={16} />
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </>
  );
}
