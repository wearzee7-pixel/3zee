"use client";
import { useState } from "react";
import { notFound } from "next/navigation";
import Navbar from "../../components/Navbar";
import Footer from "../../components/Footer";
import ProductCard from "../../components/ProductCard";
import { products, formatPrice } from "../../lib/data";
import { Star, ChevronLeft, Share2, Heart, MessageCircle, Play } from "lucide-react";
import Link from "next/link";

export default function ProductDetailPage({ params }: { params: { id: string } }) {
  const product = products.find((p) => p.id === Number(params.id));

  if (!product) return notFound();

  const related = products.filter((p) => p.category === product.category && p.id !== product.id).slice(0, 4);

  return <ProductDetailClient product={product} related={related} />;
}

function ProductDetailClient({ product, related }: { product: any; related: any[] }) {
  const [selectedImage, setSelectedImage] = useState(0);
  const [selectedSize, setSelectedSize] = useState("");
  const [selectedColor, setSelectedColor] = useState("");

  const discount = Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100);

  return (
    <>
      <Navbar />

      {/* Breadcrumb */}
      <div className="bg-[#0d1f3c] pt-24 pb-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-2 font-body text-sm text-white/60">
            <Link href="/" className="hover:text-[#c9a227] transition-colors">Home</Link>
            <span>/</span>
            <Link href="/produk" className="hover:text-[#c9a227] transition-colors">Produk</Link>
            <span>/</span>
            <span className="text-white/90">{product.name}</span>
          </div>
        </div>
      </div>

      <div className="bg-[#faf8f4] py-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Link
            href="/produk"
            className="inline-flex items-center gap-2 text-[#0d1f3c] font-body text-sm mb-8 hover:text-[#c9a227] transition-colors group"
          >
            <ChevronLeft size={16} className="group-hover:-translate-x-1 transition-transform" />
            Kembali ke Produk
          </Link>

          {/* Main product section */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 mb-20">
            {/* Images */}
            <div>
              {/* Main image */}
              <div className="img-zoom-wrapper aspect-[4/5] rounded-sm overflow-hidden mb-4 bg-white elegant-card">
                <img
                  src={product.images[selectedImage] || product.image}
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Thumbnails */}
              <div className="flex gap-3">
                {product.images.map((img: string, i: number) => (
                  <button
                    key={i}
                    onClick={() => setSelectedImage(i)}
                    className={`w-20 h-24 rounded-sm overflow-hidden border-2 transition-all flex-shrink-0 ${
                      selectedImage === i ? "border-[#c9a227]" : "border-transparent"
                    }`}
                  >
                    <img src={img} alt={`View ${i + 1}`} className="w-full h-full object-cover" />
                  </button>
                ))}

                {/* Video placeholder */}
                <button className="w-20 h-24 rounded-sm border-2 border-dashed border-[#c9a227]/40 flex flex-col items-center justify-center gap-1 hover:border-[#c9a227] transition-colors bg-white">
                  <Play className="w-5 h-5 text-[#c9a227]" />
                  <span className="text-[9px] font-body text-gray-500">Video</span>
                </button>
              </div>
            </div>

            {/* Product info */}
            <div>
              {/* Badges */}
              <div className="flex gap-2 mb-4">
                {product.isNew && (
                  <span className="bg-[#0d1f3c] text-[#c9a227] text-[10px] font-body font-bold tracking-widest uppercase px-3 py-1">New Arrival</span>
                )}
                {product.isBestSeller && (
                  <span className="bg-[#c9a227] text-[#0d1f3c] text-[10px] font-body font-bold tracking-widest uppercase px-3 py-1">Best Seller</span>
                )}
              </div>

              {/* Category */}
              <p className="text-[#c9a227] text-xs font-body tracking-[0.3em] uppercase mb-2">{product.category}</p>

              {/* Name */}
              <h1 className="font-serif text-3xl md:text-4xl font-bold text-[#0d1f3c] mb-4">{product.name}</h1>

              {/* Rating */}
              <div className="flex items-center gap-3 mb-5">
                <div className="flex">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} size={16} className={i < Math.floor(product.rating) ? "text-[#f0c73e] fill-[#f0c73e]" : "text-gray-300"} />
                  ))}
                </div>
                <span className="font-body text-gray-600 text-sm">{product.rating} ({product.sold} terjual)</span>
              </div>

              {/* Price */}
              <div className="flex items-end gap-4 mb-6 pb-6 border-b border-[#c9a227]/20">
                <span className="font-serif text-3xl font-bold text-[#0d1f3c]">{formatPrice(product.price)}</span>
                <span className="font-body text-gray-400 text-lg line-through">{formatPrice(product.originalPrice)}</span>
                <span className="bg-red-100 text-red-600 text-xs font-body font-bold px-2 py-1 rounded">-{discount}%</span>
              </div>

              {/* Description */}
              <p className="font-body text-gray-600 text-sm leading-relaxed mb-6">{product.description}</p>

              {/* Colors */}
              <div className="mb-6">
                <p className="font-body text-[#0d1f3c] font-semibold text-sm tracking-wider uppercase mb-3">
                  Pilihan Warna: <span className="text-[#c9a227] normal-case font-normal">{selectedColor || "Pilih warna"}</span>
                </p>
                <div className="flex gap-2 flex-wrap">
                  {product.colors.map((color: string) => (
                    <button
                      key={color}
                      onClick={() => setSelectedColor(color)}
                      className={`px-4 py-2 border rounded-sm font-body text-sm transition-all ${
                        selectedColor === color
                          ? "border-[#c9a227] bg-[#c9a227]/10 text-[#0d1f3c] font-semibold"
                          : "border-gray-300 text-gray-600 hover:border-[#c9a227]"
                      }`}
                    >
                      {color}
                    </button>
                  ))}
                </div>
              </div>

              {/* Sizes */}
              <div className="mb-8">
                <p className="font-body text-[#0d1f3c] font-semibold text-sm tracking-wider uppercase mb-3">
                  Pilihan Ukuran: <span className="text-[#c9a227] normal-case font-normal">{selectedSize || "Pilih ukuran"}</span>
                </p>
                <div className="flex gap-2 flex-wrap">
                  {product.sizes.map((size: string) => (
                    <button
                      key={size}
                      onClick={() => setSelectedSize(size)}
                      className={`w-12 h-12 border rounded-sm font-body text-sm font-semibold transition-all ${
                        selectedSize === size
                          ? "border-[#c9a227] bg-[#0d1f3c] text-[#c9a227]"
                          : "border-gray-300 text-gray-600 hover:border-[#c9a227] hover:bg-[#c9a227]/5"
                      }`}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>

              {/* CTA buttons */}
              <div className="flex gap-3 mb-6">
                <a
                  href={`https://wa.me/6281234567890?text=Halo, saya tertarik dengan produk ${encodeURIComponent(product.name)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 flex items-center justify-center gap-2 bg-green-500 hover:bg-green-600 text-white py-4 rounded-sm font-body font-semibold text-sm tracking-widest uppercase transition-all"
                >
                  <MessageCircle size={16} />
                  Order via WhatsApp
                </a>
                <button className="w-14 h-14 border border-[#c9a227]/30 hover:border-[#c9a227] flex items-center justify-center rounded-sm transition-all group">
                  <Heart className="w-5 h-5 text-gray-400 group-hover:text-red-500 transition-colors" />
                </button>
                <button className="w-14 h-14 border border-[#c9a227]/30 hover:border-[#c9a227] flex items-center justify-center rounded-sm transition-all">
                  <Share2 className="w-5 h-5 text-gray-400" />
                </button>
              </div>

              {/* Guarantees */}
              <div className="grid grid-cols-2 gap-3">
                {[
                  { icon: "🔒", label: "Pembayaran Aman" },
                  { icon: "📦", label: "Packaging Premium" },
                  { icon: "↩️", label: "Retur 7 Hari" },
                  { icon: "✨", label: "100% Original" },
                ].map((g) => (
                  <div key={g.label} className="flex items-center gap-2 p-3 bg-white border border-[#c9a227]/15 rounded-sm">
                    <span className="text-lg">{g.icon}</span>
                    <span className="font-body text-gray-600 text-xs">{g.label}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Related products */}
          {related.length > 0 && (
            <div>
              <div className="flex items-center gap-4 mb-8">
                <div className="h-px w-10 bg-[#c9a227]" />
                <h2 className="font-serif text-2xl md:text-3xl font-bold text-[#0d1f3c]">Produk Terkait</h2>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {related.map((p) => (
                  <ProductCard key={p.id} product={p} />
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      <Footer />
    </>
  );
}
