import { testimonials } from "@/app/lib/data";
import { Star, Quote } from "lucide-react";

export default function TestimonialSection() {
  return (
    <section className="py-20 bg-[#0d1f3c]" id="testimoni">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-14">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="h-px w-10 bg-[#c9a227]" />
            <span className="text-[#c9a227] text-xs tracking-[0.4em] uppercase font-body">Testimoni</span>
            <div className="h-px w-10 bg-[#c9a227]" />
          </div>
          <h2 className="font-serif text-4xl md:text-5xl font-bold text-white mb-4">
            Apa Kata Mereka?
          </h2>
          <p className="font-body text-white/60 max-w-md mx-auto text-sm">
            Kepuasan pelanggan adalah kebanggaan terbesar kami. Simak pengalaman nyata dari pelanggan setia 3ZEE.
          </p>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {testimonials.map((t, i) => (
            <div
              key={t.id}
              className="bg-[#1a2f5e]/50 border border-[#c9a227]/20 hover:border-[#c9a227]/50 p-6 rounded-sm transition-all duration-300 hover:bg-[#1a2f5e]/80 group"
            >
              {/* Quote icon */}
              <Quote className="text-[#c9a227]/30 w-8 h-8 mb-4 group-hover:text-[#c9a227]/60 transition-colors" />

              {/* Stars */}
              <div className="flex gap-0.5 mb-4">
                {[...Array(t.rating)].map((_, j) => (
                  <Star key={j} size={13} className="text-[#f0c73e] fill-[#f0c73e]" />
                ))}
              </div>

              {/* Review */}
              <p className="font-body text-white/80 text-sm leading-relaxed mb-5 italic">"{t.review}"</p>

              {/* Product tag */}
              <div className="mb-5">
                <span className="bg-[#c9a227]/10 text-[#c9a227] text-[10px] font-body tracking-wider px-2 py-1 border border-[#c9a227]/30">
                  {t.product}
                </span>
              </div>

              {/* Author */}
              <div className="flex items-center gap-3 border-t border-white/10 pt-4">
                <div className="w-10 h-10 rounded-full overflow-hidden border-2 border-[#c9a227]/40">
                  <img src={t.avatar} alt={t.name} className="w-full h-full object-cover" />
                </div>
                <div>
                  <p className="font-serif text-white font-semibold text-sm">{t.name}</p>
                  <p className="text-white/50 text-xs font-body">{t.location}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Trust badges */}
        <div className="mt-14 grid grid-cols-2 md:grid-cols-4 gap-6 border-t border-[#c9a227]/20 pt-12">
          {[
            { icon: "⭐", label: "4.9/5 Rating", sub: "dari 10K+ ulasan" },
            { icon: "🚚", label: "Pengiriman Cepat", sub: "ke seluruh Indonesia" },
            { icon: "💯", label: "100% Original", sub: "garansi keaslian produk" },
            { icon: "↩️", label: "Easy Return", sub: "7 hari pengembalian" },
          ].map((badge) => (
            <div key={badge.label} className="text-center">
              <div className="text-3xl mb-2">{badge.icon}</div>
              <div className="font-serif text-white font-semibold text-sm">{badge.label}</div>
              <div className="text-white/50 text-xs font-body mt-1">{badge.sub}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
