import { MapPin, Phone, Mail, Clock, MessageCircle } from "lucide-react";

export default function ContactSection() {
  return (
    <section className="py-20 bg-[#faf8f4]" id="kontak">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-14">
          <div className="luxury-divider mb-4">
            <span className="text-[#c9a227] text-xs tracking-[0.4em] uppercase font-body font-medium px-4">Kontak</span>
          </div>
          <h2 className="font-serif text-4xl md:text-5xl font-bold text-[#0d1f3c] mb-4">
            Hubungi Kami
          </h2>
          <p className="font-body text-gray-500 text-sm max-w-md mx-auto">
            Kami siap membantu Anda menemukan koleksi yang sempurna.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
          {/* Contact info */}
          <div className="space-y-6">
            {/* WhatsApp */}
            <a
              href="https://wa.me/6281234567890"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-5 p-6 bg-white border border-[#c9a227]/20 hover:border-[#c9a227] rounded-sm group transition-all duration-300 hover:shadow-lg"
            >
              <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform">
                <MessageCircle className="text-white w-5 h-5" />
              </div>
              <div>
                <p className="font-body text-gray-400 text-xs tracking-widest uppercase mb-1">WhatsApp</p>
                <p className="font-serif text-[#0d1f3c] font-semibold text-lg">+62 812-3456-7890</p>
                <p className="font-body text-gray-500 text-sm">Chat langsung dengan tim kami</p>
              </div>
            </a>

            {/* Email */}
            <a
              href="mailto:hello@3zee.id"
              className="flex items-center gap-5 p-6 bg-white border border-[#c9a227]/20 hover:border-[#c9a227] rounded-sm group transition-all duration-300 hover:shadow-lg"
            >
              <div className="w-12 h-12 bg-[#0d1f3c] rounded-full flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform">
                <Mail className="text-[#c9a227] w-5 h-5" />
              </div>
              <div>
                <p className="font-body text-gray-400 text-xs tracking-widest uppercase mb-1">Email</p>
                <p className="font-serif text-[#0d1f3c] font-semibold text-lg">hello@3zee.id</p>
                <p className="font-body text-gray-500 text-sm">Respons dalam 1x24 jam</p>
              </div>
            </a>

            {/* Address */}
            <div className="flex items-start gap-5 p-6 bg-white border border-[#c9a227]/20 rounded-sm">
              <div className="w-12 h-12 bg-[#c9a227] rounded-full flex items-center justify-center flex-shrink-0">
                <MapPin className="text-[#0d1f3c] w-5 h-5" />
              </div>
              <div>
                <p className="font-body text-gray-400 text-xs tracking-widest uppercase mb-1">Alamat</p>
                <p className="font-serif text-[#0d1f3c] font-semibold text-base">Jl. Slamet Riyadi No. 88</p>
                <p className="font-body text-gray-500 text-sm">Surakarta, Jawa Tengah 57141</p>
              </div>
            </div>

            {/* Hours */}
            <div className="flex items-center gap-5 p-6 bg-white border border-[#c9a227]/20 rounded-sm">
              <div className="w-12 h-12 bg-[#1a2f5e] rounded-full flex items-center justify-center flex-shrink-0">
                <Clock className="text-[#c9a227] w-5 h-5" />
              </div>
              <div>
                <p className="font-body text-gray-400 text-xs tracking-widest uppercase mb-1">Jam Operasional</p>
                <p className="font-serif text-[#0d1f3c] font-semibold text-base">Senin – Sabtu: 09.00 – 20.00</p>
                <p className="font-body text-gray-500 text-sm">Minggu & Hari Libur: 10.00 – 17.00</p>
              </div>
            </div>
          </div>

          {/* Map placeholder */}
          <div className="rounded-sm overflow-hidden border border-[#c9a227]/20 min-h-[400px] relative bg-[#0d1f3c]">
            {/* Simulated map */}
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center">
                <div className="w-16 h-16 bg-[#c9a227] rounded-full flex items-center justify-center mx-auto mb-4 shadow-2xl">
                  <MapPin className="text-[#0d1f3c] w-8 h-8" />
                </div>
                <p className="font-serif text-white text-xl font-semibold mb-2">3ZEE Fashion Store</p>
                <p className="font-body text-white/70 text-sm mb-6">Jl. Slamet Riyadi No. 88, Surakarta</p>
                <a
                  href="https://maps.google.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-gold inline-block px-6 py-2.5 text-[#0d1f3c] text-xs font-body font-bold tracking-widest uppercase rounded-sm"
                >
                  Buka di Google Maps
                </a>
              </div>
            </div>

            {/* Grid overlay for map aesthetic */}
            <svg className="absolute inset-0 w-full h-full opacity-10" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                  <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#c9a227" strokeWidth="0.5"/>
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#grid)" />
            </svg>
          </div>
        </div>
      </div>
    </section>
  );
}
