import Link from "next/link";
import { categories } from "@/app/lib/data";

export default function CategorySection() {
  return (
    <section className="py-20 bg-white" id="kategori">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="luxury-divider mb-4">
            <span className="text-[#c9a227] text-xs tracking-[0.4em] uppercase font-body font-medium px-4">Koleksi</span>
          </div>
          <h2 className="font-serif text-4xl md:text-5xl font-bold text-[#0d1f3c] mb-4">
            Temukan Kategori
          </h2>
          <p className="font-body text-gray-500 text-base max-w-md mx-auto">
            Jelajahi koleksi fashion premium kami yang dikurasi dengan cermat untuk setiap gaya hidup.
          </p>
        </div>

        {/* Categories grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
          {categories.map((cat, i) => (
            <Link
              key={cat.id}
              href={`/produk?kategori=${cat.name}`}
              className="group relative overflow-hidden rounded-sm cursor-pointer"
              style={{ animationDelay: `${i * 100}ms` }}
            >
              {/* Image */}
              <div className="img-zoom-wrapper aspect-[3/4]">
                <img
                  src={cat.image}
                  alt={cat.name}
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#0d1f3c]/90 via-[#0d1f3c]/30 to-transparent" />

              {/* Hover overlay */}
              <div className="absolute inset-0 bg-[#c9a227]/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

              {/* Content */}
              <div className="absolute bottom-0 left-0 right-0 p-4">
                <p className="text-2xl mb-1">{cat.icon}</p>
                <h3 className="font-serif text-white font-semibold text-lg leading-tight">{cat.name}</h3>
                <p className="font-body text-[#c9a227] text-xs tracking-wider mt-1">{cat.count} Produk</p>
              </div>

              {/* Gold accent border on hover */}
              <div className="absolute inset-0 border-2 border-transparent group-hover:border-[#c9a227]/60 transition-colors duration-300 rounded-sm" />
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
