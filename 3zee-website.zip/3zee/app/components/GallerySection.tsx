import { galleryImages } from "@/app/lib/data";

export default function GallerySection() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="luxury-divider mb-4">
            <span className="text-[#c9a227] text-xs tracking-[0.4em] uppercase font-body font-medium px-4">Lifestyle</span>
          </div>
          <h2 className="font-serif text-4xl md:text-5xl font-bold text-[#0d1f3c] mb-4">
            Galeri Brand
          </h2>
          <p className="font-body text-gray-500 text-sm max-w-md mx-auto">
            Inspirasi gaya hidup premium bersama koleksi eksklusif 3ZEE.
          </p>
        </div>

        {/* Masonry-like grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {/* Row 1: tall + short */}
          <div className="img-zoom-wrapper row-span-2 overflow-hidden rounded-sm" style={{ gridRow: "span 2" }}>
            <img src={galleryImages[0]} alt="Gallery 1" className="w-full h-full object-cover aspect-[3/5]" />
          </div>
          <div className="img-zoom-wrapper overflow-hidden rounded-sm">
            <img src={galleryImages[1]} alt="Gallery 2" className="w-full h-full object-cover aspect-[4/3]" />
          </div>
          <div className="img-zoom-wrapper overflow-hidden rounded-sm">
            <img src={galleryImages[2]} alt="Gallery 3" className="w-full h-full object-cover aspect-[4/3]" />
          </div>
          <div className="img-zoom-wrapper overflow-hidden rounded-sm">
            <img src={galleryImages[3]} alt="Gallery 4" className="w-full h-full object-cover aspect-[4/3]" />
          </div>
          <div className="img-zoom-wrapper overflow-hidden rounded-sm">
            <img src={galleryImages[4]} alt="Gallery 5" className="w-full h-full object-cover aspect-[4/3]" />
          </div>
          <div className="img-zoom-wrapper overflow-hidden rounded-sm col-span-2 md:col-span-1">
            <img src={galleryImages[5]} alt="Gallery 6" className="w-full h-full object-cover aspect-[4/3]" />
          </div>
        </div>

        {/* Instagram handle */}
        <div className="text-center mt-10">
          <a
            href="https://instagram.com/3zee.fashion"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-3 text-[#0d1f3c] font-body font-semibold text-sm tracking-widest uppercase hover:text-[#c9a227] transition-colors group"
          >
            <div className="h-px w-8 bg-current group-hover:w-12 transition-all duration-300" />
            Follow @3zee.fashion di Instagram
            <div className="h-px w-8 bg-current group-hover:w-12 transition-all duration-300" />
          </a>
        </div>
      </div>
    </section>
  );
}
