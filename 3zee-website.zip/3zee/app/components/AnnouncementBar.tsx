export default function AnnouncementBar() {
  const items = [
    "✦ FREE ONGKIR untuk pembelian di atas Rp 500.000",
    "✦ Koleksi Baru telah tiba — Explore Now",
    "✦ Garansi kualitas premium setiap produk",
    "✦ Pembayaran aman & terpercaya",
    "✦ Customer service 7 hari seminggu",
  ];

  return (
    <div className="bg-[#0d1f3c] py-2.5 overflow-hidden">
      <div className="flex animate-marquee whitespace-nowrap">
        {[...items, ...items].map((item, i) => (
          <span
            key={i}
            className="text-[#c9a227] text-xs font-body tracking-widest uppercase mx-8 inline-block"
          >
            {item}
          </span>
        ))}
      </div>
    </div>
  );
}
