import Link from "next/link";
import { Star, Eye } from "lucide-react";
import { formatPrice } from "@/app/lib/data";

interface Product {
  id: number;
  name: string;
  category: string;
  price: number;
  originalPrice: number;
  rating: number;
  sold: number;
  image: string;
  isNew: boolean;
  isBestSeller: boolean;
}

interface ProductCardProps {
  product: Product;
  compact?: boolean;
}

export default function ProductCard({ product, compact = false }: ProductCardProps) {
  const discount = Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100);

  return (
    <Link href={`/produk/${product.id}`} className="product-card elegant-card block rounded-sm overflow-hidden group">
      {/* Image */}
      <div className={`img-zoom-wrapper relative ${compact ? "aspect-[3/4]" : "aspect-[3/4]"}`}>
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover"
        />

        {/* Badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-1.5">
          {product.isNew && (
            <span className="bg-[#0d1f3c] text-[#c9a227] text-[10px] font-body font-semibold tracking-widest uppercase px-2 py-1">
              New
            </span>
          )}
          {product.isBestSeller && (
            <span className="bg-[#c9a227] text-[#0d1f3c] text-[10px] font-body font-semibold tracking-widest uppercase px-2 py-1">
              Best Seller
            </span>
          )}
          {discount > 0 && (
            <span className="bg-red-600 text-white text-[10px] font-body font-semibold tracking-wider px-2 py-1">
              -{discount}%
            </span>
          )}
        </div>

        {/* Hover overlay */}
        <div className="absolute inset-0 bg-[#0d1f3c]/30 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
          <div className="flex items-center gap-2 bg-white/95 px-4 py-2 rounded-sm text-[#0d1f3c] text-xs font-body font-semibold tracking-wider uppercase">
            <Eye size={14} />
            Lihat Detail
          </div>
        </div>
      </div>

      {/* Info */}
      <div className="p-4">
        <p className="text-[#c9a227] text-[10px] font-body tracking-[0.3em] uppercase mb-1">{product.category}</p>
        <h3 className="font-serif text-[#0d1f3c] font-semibold text-sm leading-tight mb-2 line-clamp-2">{product.name}</h3>

        {/* Rating */}
        <div className="flex items-center gap-1.5 mb-2.5">
          <div className="flex">
            {[...Array(5)].map((_, i) => (
              <Star
                key={i}
                size={11}
                className={i < Math.floor(product.rating) ? "text-[#f0c73e] fill-[#f0c73e]" : "text-gray-300"}
              />
            ))}
          </div>
          <span className="text-gray-500 text-[10px] font-body">({product.sold} terjual)</span>
        </div>

        {/* Price */}
        <div className="flex items-center gap-2">
          <span className="font-serif text-[#0d1f3c] font-bold text-base">{formatPrice(product.price)}</span>
          {product.originalPrice > product.price && (
            <span className="text-gray-400 text-xs line-through font-body">{formatPrice(product.originalPrice)}</span>
          )}
        </div>
      </div>
    </Link>
  );
}
