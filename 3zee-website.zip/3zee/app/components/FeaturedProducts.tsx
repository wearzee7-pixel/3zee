import Link from "next/link";
import ProductCard from "./ProductCard";
import { products } from "@/app/lib/data";
import { ArrowRight } from "lucide-react";

export default function FeaturedProducts() {
  const featured = products.slice(0, 8);

  return (
    <section className="py-20 bg-[#faf8f4]" id="produk-unggulan">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-4">
          <div>
            <div className="flex items-center gap-3 mb-3">
              <div className="h-px w-10 bg-[#c9a227]" />
              <span className="text-[#c9a227] text-xs tracking-[0.4em] uppercase font-body">Koleksi Pilihan</span>
            </div>
            <h2 className="font-serif text-4xl md:text-5xl font-bold text-[#0d1f3c]">
              Produk Unggulan
            </h2>
          </div>
          <Link
            href="/produk"
            className="flex items-center gap-2 text-[#c9a227] font-body text-sm font-semibold tracking-wider uppercase hover:gap-4 transition-all duration-300 group"
          >
            Lihat Semua
            <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
          {featured.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>
    </section>
  );
}
