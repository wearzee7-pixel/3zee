import Link from "next/link";

export default function CTASection() {
  return (
    <section className="relative py-28 overflow-hidden">
      {/* Background */}
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: `url('https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=1920&h=600&fit=crop')`,
        }}
      />
      <div className="absolute inset-0 bg-[#0d1f3c]/88" />

      {/* Decorative */}
      <div className="absolute inset-0 flex items-center justify-center opacity-5">
        <div className="text-[20rem] font-serif font-bold text-white select-none">3ZEE</div>
      </div>

      {/* Content */}
      <div className="relative z-10 text-center max-w-3xl mx-auto px-6">
        <div className="flex items-center justify-center gap-4 mb-6">
          <div className="h-px w-12 bg-[#c9a227]" />
          <span className="text-[#c9a227] text-xs tracking-[0.4em] uppercase font-body">Exclusive Collection</span>
          <div className="h-px w-12 bg-[#c9a227]" />
        </div>

        <h2 className="font-serif text-4xl md:text-6xl font-bold text-white mb-4 leading-tight">
          Temukan Gaya Terbaik
          <br />
          <span className="text-gold-gradient italic">Anda Bersama 3ZEE</span>
        </h2>

        <p className="font-body text-white/70 text-base md:text-lg mb-12 max-w-xl mx-auto leading-relaxed">
          Ribuan pilihan fashion premium menanti Anda. Ekspresikan diri Anda dengan koleksi eksklusif 3ZEE.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link
            href="/produk"
            className="btn-gold px-10 py-4 text-[#0d1f3c] font-body font-bold text-sm tracking-[0.2em] uppercase rounded-sm inline-block"
          >
            Lihat Produk
          </Link>
          <a
            href="https://wa.me/6281234567890"
            target="_blank"
            rel="noopener noreferrer"
            className="btn-navy px-10 py-4 text-white font-body font-semibold text-sm tracking-[0.2em] uppercase rounded-sm inline-block"
          >
            Hubungi Kami
          </a>
        </div>
      </div>
    </section>
  );
}
