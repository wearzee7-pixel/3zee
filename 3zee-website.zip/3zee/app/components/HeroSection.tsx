"use client";
import { useEffect, useRef } from "react";
import Link from "next/link";
import { ChevronDown } from "lucide-react";

export default function HeroSection() {
  const titleRef = useRef<HTMLHeadingElement>(null);
  const subtitleRef = useRef<HTMLParagraphElement>(null);
  const buttonsRef = useRef<HTMLDivElement>(null);
  const badgeRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const elements = [badgeRef.current, titleRef.current, subtitleRef.current, buttonsRef.current];
    elements.forEach((el, i) => {
      if (el) {
        el.style.opacity = "0";
        el.style.transform = "translateY(30px)";
        setTimeout(() => {
          el!.style.transition = "opacity 0.9s ease, transform 0.9s ease";
          el!.style.opacity = "1";
          el!.style.transform = "translateY(0)";
        }, 200 + i * 200);
      }
    });
  }, []);

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background image */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: `url('https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=1920&h=1080&fit=crop')`,
        }}
      />

      {/* Gradient overlay */}
      <div className="absolute inset-0 hero-overlay" />

      {/* Decorative elements */}
      <div className="absolute top-1/4 left-8 w-px h-32 bg-gradient-to-b from-transparent via-[#c9a227]/60 to-transparent" />
      <div className="absolute top-1/4 right-8 w-px h-32 bg-gradient-to-b from-transparent via-[#c9a227]/60 to-transparent" />

      {/* Content */}
      <div className="relative z-10 text-center max-w-5xl mx-auto px-6">
        {/* Badge */}
        <div ref={badgeRef} className="inline-flex items-center gap-3 mb-8">
          <div className="h-px w-12 bg-[#c9a227]" />
          <span className="text-[#c9a227] text-xs tracking-[0.4em] uppercase font-body font-medium">Premium Fashion Brand</span>
          <div className="h-px w-12 bg-[#c9a227]" />
        </div>

        {/* Title */}
        <h1 ref={titleRef} className="font-serif text-5xl md:text-7xl lg:text-8xl font-bold text-white mb-6 leading-tight">
          WHERE{" "}
          <span className="text-gold-gradient italic">STYLE</span>
          <br />
          MEETS <span className="text-gold-gradient italic">SOUL</span>
        </h1>

        {/* Divider */}
        <div className="flex items-center justify-center gap-4 mb-8">
          <div className="h-px w-16 bg-[#c9a227]/50" />
          <div className="w-1.5 h-1.5 rounded-full bg-[#c9a227]" />
          <div className="h-px w-16 bg-[#c9a227]/50" />
        </div>

        {/* Subtitle */}
        <p ref={subtitleRef} className="font-body text-white/80 text-lg md:text-xl max-w-2xl mx-auto mb-12 leading-relaxed tracking-wide">
          Fashion premium dengan kualitas terbaik dan pelayanan terpercaya.
          <br className="hidden sm:block" />
          Temukan koleksi eksklusif yang mencerminkan kepribadian Anda.
        </p>

        {/* Buttons */}
        <div ref={buttonsRef} className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <Link
            href="/produk"
            className="btn-gold px-10 py-4 text-[#0d1f3c] font-body font-bold text-sm tracking-[0.2em] uppercase rounded-sm min-w-[180px] text-center"
          >
            Lihat Produk
          </Link>
          <a
            href="#kontak"
            className="btn-navy px-10 py-4 text-white font-body font-semibold text-sm tracking-[0.2em] uppercase rounded-sm min-w-[180px] text-center"
          >
            Hubungi Kami
          </a>
        </div>

        {/* Stats */}
        <div className="mt-20 grid grid-cols-3 gap-8 max-w-md mx-auto">
          {[
            { num: "500+", label: "Produk" },
            { num: "10K+", label: "Pelanggan" },
            { num: "5★", label: "Rating" },
          ].map((stat) => (
            <div key={stat.label} className="text-center">
              <div className="font-serif text-2xl font-bold text-gold-gradient">{stat.num}</div>
              <div className="text-white/60 text-xs tracking-widest uppercase font-body mt-1">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <ChevronDown className="text-[#c9a227] w-6 h-6" />
      </div>
    </section>
  );
}
