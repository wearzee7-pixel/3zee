import Link from "next/link";
import { products, formatPrice } from "@/app/lib/data";
import { ArrowRight, Star, TrendingUp } from "lucide-react";

export default function BestSellers() {
  const bestSellers = products.filter((p) => p.isBestSeller);

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-14">
          <div className="luxury-divider mb-4">
            <span className="text-[#c9a227] text-xs tracking-[0.4em] uppercase font-body font-medium px-4 flex items-center gap-2">
              <TrendingUp size={14} />
              Best Seller
            </span>
          </div>
          <h2 className="font-serif text-4xl md:text-5xl font-bold text-[#0d1f3c] mb-4">
            Produk Terlaris
          </h2>
          <p className="font-body text-gray-500 max-w-md mx-auto text-sm">
            Pilihan favorit pelanggan setia 3ZEE — kualitas premium yang tak pernah mengecewakan.
          </p>
        </div>

        {/* Featured bestseller + grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Big featured */}
          <Link
            href={`/produk/${bestSellers[0]?.id}`}
            className="lg:col-span-5 group relative overflow-hidden rounded-sm elegant-card"
          >
            <div className="img-zoom-wrapper aspect-[4/5]">
              <img
                src={bestSellers[0]?.image}
                alt={bestSellers[0]?.name}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="absolute inset-0 bg-gradient-to-t from-[#0d1f3c]/90 via-transparent to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-8">
              <span className="bg-[#c9a227] text-[#0d1f3c] text-[9px] font-body font-bold tracking-widest uppercase px-3 py-1 mb-3 inline-block">
                #1 Best Seller
              </span>
              <h3 className="font-serif text-white text-2xl font-bold mb-1">{bestSellers[0]?.name}</h3>
              <div className="flex items-center gap-2 mb-3">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} size={12} className="text-[#f0c73e] fill-[#f0c73e]" />
                ))}
                <span className="text-white/70 text-xs font-body">{bestSellers[0]?.sold} terjual</span>
              </div>
              <p className="font-serif text-[#c9a227] font-bold text-xl">{formatPrice(bestSellers[0]?.price)}</p>
            </div>
          </Link>

          {/* Grid */}
          <div className="lg:col-span-7 grid grid-cols-2 gap-4">
            {bestSellers.slice(1, 5).map((product, i) => (
              <Link
                key={product.id}
                href={`/produk/${product.id}`}
                className="group elegant-card rounded-sm overflow-hidden"
              >
                <div className="img-zoom-wrapper aspect-[3/4]">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-3">
                  <div className="flex items-center justify-between mb-1">
                    <p className="text-[#c9a227] text-[9px] font-body tracking-widest uppercase">{product.category}</p>
                    <span className="bg-[#c9a227]/10 text-[#c9a227] text-[9px] font-body font-semibold px-1.5 py-0.5">#{i + 2}</span>
                  </div>
                  <h3 className="font-serif text-[#0d1f3c] text-sm font-semibold line-clamp-1 mb-1">{product.name}</h3>
                  <div className="flex items-center gap-1 mb-1.5">
                    {[...Array(5)].map((_, j) => (
                      <Star key={j} size={9} className={j < Math.floor(product.rating) ? "text-[#f0c73e] fill-[#f0c73e]" : "text-gray-300"} />
                    ))}
                  </div>
                  <p className="font-serif text-[#0d1f3c] font-bold text-sm">{formatPrice(product.price)}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>

        {/* View all */}
        <div className="text-center mt-12">
          <Link
            href="/produk?filter=bestseller"
            className="inline-flex items-center gap-3 border border-[#0d1f3c] text-[#0d1f3c] px-8 py-3 font-body font-semibold text-sm tracking-widest uppercase hover:bg-[#0d1f3c] hover:text-white transition-all duration-300 rounded-sm group"
          >
            Lihat Semua Best Seller
            <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>
      </div>
    </section>
  );
}
