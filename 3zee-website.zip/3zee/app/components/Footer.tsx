import Link from "next/link";
import Image from "next/image";
import { Globe, Heart, Video, MessageCircle, Mail, MapPin } from "lucide-react";


export default function Footer() {
  return (
    <footer className="bg-[#060b17] text-white">
      {/* Main footer */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Brand */}
          <div className="lg:col-span-1">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-full overflow-hidden border border-[#c9a227]/40">
                <Image src="/logo.jpg" alt="3ZEE" width={48} height={48} className="object-cover" />
              </div>
              <div>
                <span className="text-xl font-serif font-bold text-gold-gradient">3ZEE</span>
              </div>
            </div>
            <p className="text-[#c9a227] text-xs tracking-[0.3em] uppercase font-body mb-4">Where Style Meets Soul</p>
            <p className="font-body text-white/60 text-sm leading-relaxed mb-6">
              Brand fashion premium Indonesia dengan kualitas terbaik dan pelayanan terpercaya sejak 2017.
            </p>

            {/* Social */}
            <div className="flex gap-3">
              {[
                { icon: Globe, href: "https://instagram.com", label: "Instagram" },
                { icon: Heart, href: "https://facebook.com", label: "Facebook" },
                { icon: MessageCircle, href: "https://twitter.com", label: "Twitter" },
                { icon: Video, href: "https://youtube.com", label: "YouTube" },
              ].map(({ icon: Icon, href, label }) => (
                <a
                  key={label}
                  href={href}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={label}
                  className="w-9 h-9 border border-[#c9a227]/30 flex items-center justify-center hover:border-[#c9a227] hover:bg-[#c9a227]/10 transition-all duration-300 rounded-sm group"
                >
                  <Icon className="w-4 h-4 text-white/60 group-hover:text-[#c9a227] transition-colors" />
                </a>
              ))}
            </div>
          </div>

          {/* Navigation */}
          <div>
            <h4 className="font-serif text-white font-semibold mb-5 text-lg">Navigasi</h4>
            <ul className="space-y-3">
              {[
                { href: "/", label: "Home" },
                { href: "/produk", label: "Produk" },
                { href: "/#tentang", label: "Tentang Kami" },
                { href: "/#testimoni", label: "Testimoni" },
                { href: "/#kontak", label: "Kontak" },
              ].map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="font-body text-white/60 text-sm hover:text-[#c9a227] transition-colors flex items-center gap-2 group"
                  >
                    <span className="w-3 h-px bg-[#c9a227]/0 group-hover:bg-[#c9a227] transition-all duration-300 group-hover:w-4" />
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Categories */}
          <div>
            <h4 className="font-serif text-white font-semibold mb-5 text-lg">Kategori</h4>
            <ul className="space-y-3">
              {["Pria", "Wanita", "Aksesoris", "Koleksi Baru", "Best Seller"].map((cat) => (
                <li key={cat}>
                  <Link
                    href={`/produk?kategori=${cat}`}
                    className="font-body text-white/60 text-sm hover:text-[#c9a227] transition-colors flex items-center gap-2 group"
                  >
                    <span className="w-3 h-px bg-[#c9a227]/0 group-hover:bg-[#c9a227] transition-all duration-300 group-hover:w-4" />
                    {cat}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-serif text-white font-semibold mb-5 text-lg">Kontak</h4>
            <ul className="space-y-4">
              <li>
                <a href="https://wa.me/6281234567890" target="_blank" rel="noopener noreferrer" className="flex items-start gap-3 group">
                  <MessageCircle className="w-4 h-4 text-[#c9a227] flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-body text-white/60 text-xs uppercase tracking-wider mb-0.5">WhatsApp</p>
                    <p className="font-body text-white/80 text-sm group-hover:text-[#c9a227] transition-colors">+62 812-3456-7890</p>
                  </div>
                </a>
              </li>
              <li>
                <a href="mailto:hello@3zee.id" className="flex items-start gap-3 group">
                  <Mail className="w-4 h-4 text-[#c9a227] flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-body text-white/60 text-xs uppercase tracking-wider mb-0.5">Email</p>
                    <p className="font-body text-white/80 text-sm group-hover:text-[#c9a227] transition-colors">hello@3zee.id</p>
                  </div>
                </a>
              </li>
              <li>
                <div className="flex items-start gap-3">
                  <MapPin className="w-4 h-4 text-[#c9a227] flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-body text-white/60 text-xs uppercase tracking-wider mb-0.5">Alamat</p>
                    <p className="font-body text-white/80 text-sm">Jl. Slamet Riyadi No. 88<br />Surakarta, Jawa Tengah</p>
                  </div>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5 flex flex-col md:flex-row items-center justify-between gap-3">
          <p className="font-body text-white/40 text-xs">
            © 2024 3ZEE. All rights reserved. Where Style Meets Soul.
          </p>
          <div className="flex gap-5">
            {["Kebijakan Privasi", "Syarat & Ketentuan", "FAQ"].map((item) => (
              <Link key={item} href="#" className="font-body text-white/40 text-xs hover:text-[#c9a227] transition-colors">
                {item}
              </Link>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
