import Link from "next/link";
import { products, formatPrice } from "@/app/lib/data";
import { ArrowRight, Star } from "lucide-react";

export default function NewProducts() {
  const newItems = products.filter((p) => p.isNew);

  return (
    <section className="py-20 bg-[#0d1f3c] overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-4">
          <div>
            <div className="flex items-center gap-3 mb-3">
              <div className="h-px w-10 bg-[#c9a227]" />
              <span className="text-[#c9a227] text-xs tracking-[0.4em] uppercase font-body">Terbaru</span>
            </div>
            <h2 className="font-serif text-4xl md:text-5xl font-bold text-white">
              Koleksi Terbaru
            </h2>
          </div>
          <Link
            href="/produk?filter=new"
            className="flex items-center gap-2 text-[#c9a227] font-body text-sm font-semibold tracking-wider uppercase hover:gap-4 transition-all duration-300 group"
          >
            Lihat Semua
            <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>

        {/* Horizontal scroll */}
        <div className="scroll-x flex gap-5 pb-4">
          {newItems.map((product) => (
            <Link
              key={product.id}
              href={`/produk/${product.id}`}
              className="flex-none w-52 md:w-64 group"
            >
              {/* Card */}
              <div className="bg-[#1a2f5e]/50 border border-[#c9a227]/20 group-hover:border-[#c9a227]/60 transition-all duration-300 overflow-hidden rounded-sm">
                {/* Image */}
                <div className="img-zoom-wrapper aspect-[3/4] relative">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-3 left-3">
                    <span className="bg-[#c9a227] text-[#0d1f3c] text-[9px] font-body font-bold tracking-widest uppercase px-2 py-1">
                      New Arrival
                    </span>
                  </div>
                </div>

                {/* Info */}
                <div className="p-4">
                  <p className="text-[#c9a227]/70 text-[9px] font-body tracking-widest uppercase mb-1">{product.category}</p>
                  <h3 className="font-serif text-white text-sm font-semibold mb-2 line-clamp-1">{product.name}</h3>
                  <div className="flex items-center gap-1 mb-2">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} size={10} className="text-[#f0c73e] fill-[#f0c73e]" />
                    ))}
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="font-serif text-[#c9a227] font-bold text-sm">{formatPrice(product.price)}</span>
                    <span className="text-gray-400 text-xs line-through font-body">{formatPrice(product.originalPrice)}</span>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
