export default function AboutSection() {
  return (
    <section className="py-24 bg-[#faf8f4]" id="tentang">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center mb-24">
          {/* Images */}
          <div className="relative">
            <div className="grid grid-cols-2 gap-4">
              <div className="img-zoom-wrapper aspect-[3/4] rounded-sm overflow-hidden col-span-1">
                <img
                  src="https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=600&h=800&fit=crop"
                  alt="Toko 3ZEE"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="flex flex-col gap-4 col-span-1">
                <div className="img-zoom-wrapper aspect-[3/3] rounded-sm overflow-hidden">
                  <img
                    src="https://images.unsplash.com/photo-1558769132-cb1aea458c5e?w=600&h=600&fit=crop"
                    alt="Koleksi 3ZEE"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="img-zoom-wrapper aspect-[3/3] rounded-sm overflow-hidden">
                  <img
                    src="https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=600&h=600&fit=crop"
                    alt="Fashion 3ZEE"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            </div>

            {/* Floating badge */}
            <div className="absolute -bottom-6 -right-6 bg-[#0d1f3c] p-6 rounded-sm shadow-2xl">
              <div className="text-center">
                <div className="font-serif text-[#c9a227] text-3xl font-bold">7+</div>
                <div className="text-white text-xs font-body tracking-widest uppercase mt-1">Tahun<br/>Pengalaman</div>
              </div>
            </div>
          </div>

          {/* Text */}
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="h-px w-10 bg-[#c9a227]" />
              <span className="text-[#c9a227] text-xs tracking-[0.4em] uppercase font-body">Tentang Kami</span>
            </div>

            <h2 className="font-serif text-4xl md:text-5xl font-bold text-[#0d1f3c] mb-6 leading-tight">
              Cerita di Balik<br />
              <span className="text-gold-gradient italic">Keanggunan 3ZEE</span>
            </h2>

            <p className="font-body text-gray-600 text-base leading-relaxed mb-6">
              3ZEE lahir dari sebuah mimpi keluarga yang sederhana namun penuh passion — untuk menghadirkan fashion premium berkualitas dunia yang terjangkau bagi masyarakat Indonesia.
            </p>
            <p className="font-body text-gray-600 text-base leading-relaxed mb-10">
              Dimulai dari sebuah toko kecil di Surakarta pada tahun 2017, kini 3ZEE telah melayani lebih dari 10.000 pelanggan setia di seluruh nusantara. Setiap produk kami dirancang dengan detail yang teliti dan cinta yang tulus.
            </p>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-6 border-t border-[#c9a227]/20 pt-8">
              {[
                { num: "10K+", label: "Pelanggan Puas" },
                { num: "500+", label: "Koleksi Produk" },
                { num: "7+", label: "Tahun Berpengalaman" },
              ].map((s) => (
                <div key={s.label}>
                  <div className="font-serif text-2xl font-bold text-[#c9a227]">{s.num}</div>
                  <div className="text-gray-500 text-xs font-body tracking-wide mt-1">{s.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Visi Misi */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            {
              title: "Visi",
              icon: "🎯",
              text: "Menjadi brand fashion premium Indonesia yang dikenal di tingkat nasional dan internasional, dengan produk berkualitas tinggi yang mencerminkan keindahan budaya lokal.",
            },
            {
              title: "Misi",
              icon: "💫",
              text: "Menghadirkan koleksi fashion premium dengan bahan terbaik, desain elegan, dan harga yang bersahabat. Memberikan pengalaman berbelanja yang menyenangkan dan pelayanan yang sepenuh hati.",
            },
            {
              title: "Nilai",
              icon: "💎",
              text: "Kualitas tanpa kompromi, kejujuran dalam setiap transaksi, inovasi yang berkelanjutan, dan komitmen untuk selalu memuaskan pelanggan dengan standar layanan tertinggi.",
            },
          ].map((item) => (
            <div key={item.title} className="bg-white border border-[#c9a227]/20 p-8 rounded-sm hover:border-[#c9a227]/60 hover:shadow-lg transition-all duration-300">
              <div className="text-3xl mb-4">{item.icon}</div>
              <h3 className="font-serif text-[#0d1f3c] text-2xl font-bold mb-4">{item.title}</h3>
              <p className="font-body text-gray-600 text-sm leading-relaxed">{item.text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
