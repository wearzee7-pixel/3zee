import Navbar from "./components/Navbar";
import AnnouncementBar from "./components/AnnouncementBar";
import HeroSection from "./components/HeroSection";
import CategorySection from "./components/CategorySection";
import FeaturedProducts from "./components/FeaturedProducts";
import NewProducts from "./components/NewProducts";
import BestSellers from "./components/BestSellers";
import AboutSection from "./components/AboutSection";
import TestimonialSection from "./components/TestimonialSection";
import GallerySection from "./components/GallerySection";
import ContactSection from "./components/ContactSection";
import CTASection from "./components/CTASection";
import Footer from "./components/Footer";

export default function Home() {
  return (
    <main>
      <Navbar />
      <HeroSection />
      <AnnouncementBar />
      <CategorySection />
      <FeaturedProducts />
      <NewProducts />
      <BestSellers />
      <AboutSection />
      <TestimonialSection />
      <GallerySection />
      <ContactSection />
      <CTASection />
      <Footer />
    </main>
  );
}
