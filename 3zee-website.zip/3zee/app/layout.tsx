import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "3ZEE — Where Style Meets Soul",
  description: "Fashion premium dengan kualitas terbaik dan pelayanan terpercaya.",
  keywords: "fashion premium, 3ZEE, pakaian elegan, busana mewah, koleksi eksklusif",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="id">
      <body>{children}</body>
    </html>
  );
}
